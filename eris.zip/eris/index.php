<?php 
require_once("include/initialize.php"); 
$content='home.php';
$view = (isset($_GET['q']) && $_GET['q'] != '') ? $_GET['q'] : '';
switch ($view) { 
	case 'apply' :
        $title="Pendaftaran Lowongan Pekerjaan";	
		$content='applicationform.php';		
		break;
	case 'login' : 
        $title="Login";	
		$content='login.php';		
		break;
	case 'company' :
        $title="Perusahaan";	
		$content='company.php';		
		break;
	case 'hiring' :
		$title = isset($_GET['search']) ? 'Hiring in '.$_GET['search'] :"Hiring"; 
		$content='hirring.php';		
		break;		
	case 'category' :
        $title='Pencarian Untuk '. $_GET['search'];	
		$content='category.php';		
		break;
	case 'viewjob' :
        $title="Detail Pekerjaan";	
		$content='viewjob.php';		
		break;
	case 'success' :
        $title="Success";	
		$content='success.php';		
		break;
	case 'register' :
        $title="Register Member Baru";	
		$content='register.php';		
		break;
	case 'Contact' :
        $title='Kontak Kami';	
		$content='Contact.php';		
		break;	
	case 'About' :
        $title='Tentang Kami';	
		$content='About.php';		
		break;	
	case 'advancesearch' :
        $title='Pencarian Lanjut';	
		$content='advancesearch.php';		
		break;	

	case 'result' :
        $title='Hasil Pencarian';	
		$content='advancesearchresult.php';		
		break;
	case 'search-company' :
        $title='Pencarian Berdasarkan Perusahaan';	
		$content='searchbycompany.php';		
		break;	
	case 'search-function' :
        $title='Pencarian Berdasarkan Bidang';	
		$content='searchbyfunction.php';		
		break;	
	case 'search-jobtitle' :
        $title='Pencarian Berdasarkan Judul';	
		$content='searchbytitle.php';		
		break;						
	default :
	    $active_home='active';
	    $title="Home";	
		$content ='home.php';		
}
require_once("theme/templates.php");
?>